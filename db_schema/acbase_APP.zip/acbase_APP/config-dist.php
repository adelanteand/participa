<?php

define("BASEAPP","C:/wamp/www/acbase/");

////////////////////
///// BASE DE DATOS/
////////////////////
define('DB_HOST','');
define('DB_DB','');
define('DB_USER','');
define('DB_PWD','');
define('DB_PORT','3306');
define('DB_PREFIX','???_');

/////////////////////
///// CONFIGURACION /
////////////////////

define('CONF_TITULOPAGINA_POS',' | APP');
define('CONF_TITULOPAGINA','(dev) ' . CONF_TITULOPAGINA_POS);
define('CONF_DESCRIPCION','APP');
define('CONF_ORGANIZACION','APP');
define('CONF_FB_IMG',BASEAPP.'html/img/icon/android-icon-192x192.png');
define('CONF_TW_IMG',BASEAPP.'html/img/icon/android-icon-192x192.png');
define('CONF_TW_USER','???');
define('CONF_SITEADMIN','');
define('CONF_HOME','C:/wamp/www/???/');
define('CONF_HOME_BASE',BASEAPP);
define('CONF_BASEURL','http://APP.oo/');
define('CONF_URLREF','http://APP.oo/');
define('CONF_TIMEZONE','Europe/Madrid');
define('CONF_LOCALE','es_ES.utf8');
define('CONF_PUBLICOS',array('index', 'error', 'usuarios', 'ajax', 'js', 'comentarios', 'cron', 'fichero','seguridad'));
define('CONF_INDEX_MODULO','index');
define('CONF_UPLOAD_EXTENSIONES',array("doc","docx","xls","xlsx","odt","odf","zip","rar","7z","tar.gz","jpg","jpeg","png","jpg","gif","psd","ai","mp3","mp4","avi","mov","flv","mkv","pdf","tiff"));
define('CONF_UPLOAD_MAX',8);
define('CONF_UPLOAD_DATA','');

///////////////
///// SMTP ////
///////////////
define("SMTP_SERVER","");
define("SMTP_PORT",25);
define("SMTP_USERNAME","");
define("SMTP_PASSWORD","");

///////////////
///// LDAP ////
///////////////
$ldap_server = "";
$ldap_idatribute = "";
$ldap_basedn = "";
$ldap_adminuser = "";
$ldap_adminpwd = "";


//////////////////
///// API GOOGLE /
/////////////////
define("GOOGLE_API_OAUTH2_CLIENT_ID", "");
define("GOOGLE_API_OAUTH2_CLIENT_SECRET", "");
define("GOOGLE_API_REDIRECT", "");
define("GOOGLE_API_APPNAME", "");

//////////////////
///// API FACEBOOK /
/////////////////
define("FB_API_APP_ID", "");
define("FB_API_APP_SECRET", "");
define("FB_API_REDIRECT", "");
define("FB_API_APPNAME", "");