<?php
if (!file_exists('../config.php')) {
    echo "No existe config.php";
    exit;
} else {
    require_once ("../config.php");
}
require(BASEAPP.'html/index.php');