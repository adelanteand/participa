function responsive() {
    document.getElementsByClassName("topnav")[0].classList.toggle("responsive");
}

require(['jquery', 'bootstrap','bootstrap-default'], function ($) {
    // DOM ready
    $(function () {
        //console.log($);
    });
});

